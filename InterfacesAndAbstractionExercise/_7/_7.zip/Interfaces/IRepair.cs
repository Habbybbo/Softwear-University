﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _7.Interfaces
{
    public interface IRepair
    {
        public string PartName { get; }
        public int HoursWorked { get; }
    }
}
