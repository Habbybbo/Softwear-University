﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _7.Interfaces
{
    public interface IPrivate
    {
        public decimal Salary { get; }
    }
}
