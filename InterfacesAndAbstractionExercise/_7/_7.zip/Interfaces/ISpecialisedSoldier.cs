﻿using System;
using System.Collections.Generic;
using System.Text;
using _7.Enumerations;

namespace _7.Interfaces
{
    public interface ISpecialisedSoldier
    {
        public SoldierCorpEnum Corp { get; }
    }
}
