﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _7.Enumerations
{
    public enum SoldierCorpEnum
    {
        Airforces = 1,
        Marines = 2
    }
}
