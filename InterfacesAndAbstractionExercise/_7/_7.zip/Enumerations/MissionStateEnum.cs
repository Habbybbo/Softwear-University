﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _7.Enumerations
{
    public enum MissionStateEnum
    {
        inProgress = 1,
        Finished = 2
    }
}
