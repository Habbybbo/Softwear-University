﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm
{
    public class Bird : Animal
    {
        public double WingSize { get; set; }
    }
}
