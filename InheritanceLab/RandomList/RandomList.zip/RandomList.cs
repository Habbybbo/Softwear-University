﻿using System.Collections.Generic;
using System.Linq;
using System;

namespace CustomRandomList
{
    public class RandomList : List<string>
    {
        private readonly Random rnd;

        public Random Rnd { get; set; }

        public RandomList()
        {
            this.Rnd = rnd;
        }

        public string RemoveRandomElement()
        {
            int index = rnd.Next(0, this.Count);
            string str = this[index];
            this.RemoveAt(index);
            return str;

        }
    }
}
