﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person Pesho = new Person("Pesho", 20);
            Person Gosho = new Person("Gosho", 18);
            Person Stamat = new Person("Stamat", 43);

            

        }
    }
}
